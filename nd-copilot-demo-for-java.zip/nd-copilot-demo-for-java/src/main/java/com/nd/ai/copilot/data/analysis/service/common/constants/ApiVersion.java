package com.nd.ai.copilot.data.analysis.service.common.constants;

/**
 * ApiVersion
 * @author WuZhongHui
 * @version 1.0
 */
public final class ApiVersion {

    private ApiVersion(){
    }

    public static final String V1 = "/v1";
}
