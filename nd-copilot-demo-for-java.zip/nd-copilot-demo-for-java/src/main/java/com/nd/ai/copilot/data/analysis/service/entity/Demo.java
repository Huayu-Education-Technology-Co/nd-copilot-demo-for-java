package com.nd.ai.copilot.data.analysis.service.entity;

public class Demo {
}
