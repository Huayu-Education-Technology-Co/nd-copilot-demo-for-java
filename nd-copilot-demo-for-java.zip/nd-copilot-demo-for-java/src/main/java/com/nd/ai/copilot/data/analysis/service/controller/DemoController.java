package com.nd.ai.copilot.data.analysis.service.controller;

import com.nd.ai.copilot.data.analysis.service.common.constants.ApiVersion;
import com.nd.ai.copilot.data.analysis.service.pojo.vo.DemoVO;
import com.nd.gaea.rest.annotation.ApiAuth;
import com.nd.gaea.rest.support.WafContext;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import static com.nd.gaea.rest.security.authens.WafAbstractAuthenticationToken.AUTH_TYPE_MAC;

/**
 * DemoController
 *
 * @author Hank
 * @version 1.0
 */
@Slf4j
@RestController
@RequestMapping(value = ApiVersion.V1 + "/demos")
@Api(value = "Demo")
public class DemoController {

    // @ApiAuth type = AUTH_TYPE_MAC 注解表示：该接口为客户端调用接口，需要在请求头中添加Authorization: MAC Token"，UC 会根据该 Token 进行鉴权，鉴权通过后可获取用户 ID
    @ApiAuth(type = {AUTH_TYPE_MAC})
    // @ApiOperation Swagger 注解，用于自动化生成 API 文档
    @ApiOperation(value = "获取 Demo 对象", notes = "获取 Demo 对象")
    @GetMapping
    public DemoVO getDemo() {
        String userId = WafContext.getCurrentAccountId();
        log.info(userId);
        return DemoVO.builder().name("Demo").build();
    }
}
