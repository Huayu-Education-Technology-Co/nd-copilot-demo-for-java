package com.nd.ai.copilot.data.analysis.service;

import com.nd.gaea.rest.WafApplication;
import org.springframework.boot.SpringApplication;
import org.springframework.retry.annotation.EnableRetry;

/**
 * WebApplication
 *
 * @author Hank
 * @version 1.0
 */
@EnableRetry
public class WebApplication extends WafApplication {
    public static void main(String[] args) {
        SpringApplication.run(WebApplication.class, args);
    }
}
