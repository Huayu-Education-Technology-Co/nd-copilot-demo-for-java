package com.nd.ai.copilot.data.analysis.service.pojo.dto;

public class DemoDTO {
}
