package com.nd.ai.copilot.data.analysis.service.pojo.vo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.hibernate.validator.constraints.Length;

// 接口用用到的vo增加@ApiModel注解
@ApiModel(value = "Demo VO", description = "Demo VO")
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DemoVO {
    // 对应的字段增加@ApiModelProperty注解
    @ApiModelProperty(value = "名称", required = true)
    // 一些参数校验的注解也会显示在api文档上
    @Length(max = 10)
    private String name;
}
